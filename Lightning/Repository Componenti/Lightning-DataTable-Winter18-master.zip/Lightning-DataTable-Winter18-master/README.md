# Lightning DataTable Winter18

<a href="https://githubsfdeploy.herokuapp.com?owner=Karanraj&repo=Lightning-DataTable-Winter18">
  <img alt="Deploy to Salesforce"
       src="https://raw.githubusercontent.com/afawcett/githubsfdeploy/master/src/main/webapp/resources/img/deploy.png">
</a>

The Lightning DataTable component is useful to displays the data in a tabular formate which inherits the datable styling from lightning system. The column in the datatable can be displayed based on the data types for example if the email, phone or URL can displayed with the respective schema by specifying type of the column. As a developer we don’t have to use lightning design system div tags in your component to display the data in a table formate instead a single line of code.



